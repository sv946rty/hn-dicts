DNQATV JSON BY LETTER — v024

Source:
  All.DNQATV.comp-fallback-v024(1).json

Contents:
  json/       22 per-letter JSON files
  hn/         intended location for Hán-Nôm image assets
  manifest.csv
  image-assets-manifest.csv

Dictionary totals:
  main entries: 7632
  letters: 22

IMPORTANT:
The supplied v024 JSON references 22 image assets (for example hn/B-0047.png),
but the actual PNG asset files were not included with the uploaded JSON and were not
available in the working files. Therefore the hn/ directory is currently empty.
The JSON references have been preserved exactly and no image was fabricated or substituted.
